export interface GameStats {
  reputacion: number;
  conocimiento: number;
  capital: number;
  red_contactos: number;
}

export interface Option {
  texto: string;
  consecuencias: Partial<GameStats>;
  respuesta_narrativa: string;
  es_correcta?: boolean;
}

export interface Dilema {
  id: number;
  titulo: string;
  personaje_imagen?: string;
  escena_imagen?: string;
  situacion: string;
  opciones: Option[];
  tipo?: 'desafio' | 'narrativa';
}

export interface GameState {
  currentDilema: number;
  stats: GameStats;
  gamePhase: 'menu' | 'playing' | 'ended';
  showResponse: boolean;
  selectedOption: Option | null;
  language: 'es' | 'en';
}

export interface Translation {
  es: string;
  en: string;
}