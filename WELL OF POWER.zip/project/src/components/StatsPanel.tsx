import React from 'react';
import { GameStats } from '../types/game';
import { translations } from '../data/translations';
import { TrendingUp, Brain, DollarSign, Users } from 'lucide-react';

interface StatsPanelProps {
  stats: GameStats;
  language: 'es' | 'en';
}

const StatsPanel: React.FC<StatsPanelProps> = ({ stats, language }) => {
  const statIcons = {
    reputacion: TrendingUp,
    conocimiento: Brain,
    capital: DollarSign,
    red_contactos: Users
  };

  const formatCapital = (value: number) => {
    if (value >= 1000000) {
      return `$${(value / 1000000).toFixed(1)}M`;
    }
    if (value >= 1000) {
      return `$${(value / 1000).toFixed(1)}K`;
    }
    return `$${value}`;
  };

  return (
    <div className="bg-black/90 backdrop-blur-md rounded-2xl p-6 border border-white/20 shadow-2xl">
      <div className="grid grid-cols-2 gap-6">
        {Object.entries(stats).map(([key, value]) => {
          const Icon = statIcons[key as keyof typeof statIcons];
          const label = translations.stats[key as keyof typeof translations.stats][language];
          const displayValue = key === 'capital' ? formatCapital(value) : value;
          const maxValue = key === 'capital' ? 100 : 20;
          const percentage = key === 'capital' ? Math.min(100, (value / 1000000) * 100) : (value / maxValue) * 100;

          // Color schemes for different stats
          const colorSchemes = {
            reputacion: 'from-green-500 to-emerald-400',
            conocimiento: 'from-blue-500 to-cyan-400',
            capital: 'from-yellow-500 to-orange-400',
            red_contactos: 'from-purple-500 to-pink-400'
          };

          return (
            <div key={key} className="flex items-center space-x-4">
              <div className="flex-shrink-0">
                <div className={`w-12 h-12 bg-gradient-to-br ${colorSchemes[key as keyof typeof colorSchemes]} rounded-full flex items-center justify-center shadow-lg`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-bold text-white truncate mb-1">{label}</p>
                <div className="flex items-center space-x-3">
                  <div className="flex-1 bg-slate-700/50 rounded-full h-3 border border-slate-600/50">
                    <div 
                      className={`bg-gradient-to-r ${colorSchemes[key as keyof typeof colorSchemes]} h-3 rounded-full transition-all duration-700 shadow-sm`}
                      style={{ width: `${Math.max(8, percentage)}%` }}
                    />
                  </div>
                  <span className="text-sm text-white font-mono font-bold min-w-[3rem] text-right">
                    {displayValue}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default StatsPanel;