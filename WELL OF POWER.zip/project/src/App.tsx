import React, { useState } from 'react';
import { useGameState } from './hooks/useGameState';
import MainMenu from './components/MainMenu';
import GameScene from './components/GameScene';
import StatsPanel from './components/StatsPanel';
import CreditsScreen from './components/CreditsScreen';
import EndScreen from './components/EndScreen';
import dilemas from './data/dilemas.json';

function App() {
  const { gameState, startNewGame, continueGame, nextDilema, selectOption, setLanguage, getPhase } = useGameState();
  const [showCredits, setShowCredits] = useState(false);
  
  const currentDilema = dilemas.find(d => d.id === gameState.currentDilema);
  const hasSavedGame = localStorage.getItem('well-of-power-save') !== null;

  const handleContinue = () => {
    if (gameState.currentDilema >= dilemas.length - 1) {
      // Game ended
      return;
    }
    nextDilema();
  };

  const toggleLanguage = () => {
    setLanguage(gameState.language === 'es' ? 'en' : 'es');
  };

  if (showCredits) {
    return (
      <CreditsScreen 
        language={gameState.language}
        onBack={() => setShowCredits(false)}
      />
    );
  }

  if (gameState.gamePhase === 'menu') {
    return (
      <MainMenu
        language={gameState.language}
        onStartGame={startNewGame}
        onContinueGame={continueGame}
        onShowCredits={() => setShowCredits(true)}
        onToggleLanguage={toggleLanguage}
        hasSavedGame={hasSavedGame}
      />
    );
  }

  if (gameState.currentDilema >= dilemas.length || !currentDilema) {
    return (
      <EndScreen
        stats={gameState.stats}
        language={gameState.language}
        onRestart={startNewGame}
        onMainMenu={() => window.location.reload()}
      />
    );
  }

  return (
    <div className="relative">
      <GameScene
        dilema={currentDilema}
        language={gameState.language}
        showResponse={gameState.showResponse}
        selectedOption={gameState.selectedOption}
        onSelectOption={selectOption}
        onContinue={handleContinue}
        phase={getPhase()}
      />
      
      {/* Stats Panel - Fixed position */}
      <div className="fixed top-4 right-4 z-50">
        <StatsPanel 
          stats={gameState.stats} 
          language={gameState.language}
        />
      </div>
      
      {/* Language toggle - Fixed position */}
      <button
        onClick={toggleLanguage}
        className="fixed bottom-4 right-4 z-50 bg-slate-800/90 hover:bg-slate-700/90 text-white px-3 py-2 rounded-lg text-sm transition-all duration-300 backdrop-blur-sm border border-slate-600"
      >
        {gameState.language === 'es' ? 'EN' : 'ES'}
      </button>
    </div>
  );
}

export default App;