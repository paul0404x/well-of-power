import React from 'react';
import { translations } from '../data/translations';
import { Settings, Play, BookOpen, Award, Zap } from 'lucide-react';

interface MainMenuProps {
  language: 'es' | 'en';
  onStartGame: () => void;
  onContinueGame: () => void;
  onShowCredits: () => void;
  onToggleLanguage: () => void;
  hasSavedGame: boolean;
}

const MainMenu: React.FC<MainMenuProps> = ({
  language,
  onStartGame,
  onContinueGame,
  onShowCredits,
  onToggleLanguage,
  hasSavedGame
}) => {
  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background - Estilo Majotori */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800" />
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-30 transform scale-105"
        style={{ backgroundImage: `url('https://images.pexels.com/photos/256648/pexels-photo-256648.jpeg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80" />
      
      {/* Animated particles */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-3 h-3 bg-orange-400 rounded-full animate-pulse opacity-60"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-blue-400 rounded-full animate-ping opacity-40"></div>
        <div className="absolute bottom-1/3 left-1/3 w-2 h-2 bg-yellow-400 rounded-full animate-pulse opacity-50"></div>
        <div className="absolute top-3/4 right-1/2 w-1 h-1 bg-red-400 rounded-full animate-ping opacity-60"></div>
      </div>
      
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="max-w-lg w-full">
          {/* Logo section - Estilo Majotori */}
          <div className="text-center mb-12">
            <div className="relative mb-8">
              <div className="w-32 h-32 mx-auto bg-gradient-to-br from-orange-500 via-red-600 to-orange-500 rounded-full flex items-center justify-center shadow-2xl border-4 border-white/20">
                <BookOpen className="w-16 h-16 text-white drop-shadow-lg" />
              </div>
              {/* Glow effect */}
              <div className="absolute inset-0 w-32 h-32 mx-auto bg-gradient-to-br from-orange-500/30 to-red-600/30 rounded-full blur-xl"></div>
            </div>
            
            <h1 className="text-5xl font-bold text-white mb-4 tracking-wider drop-shadow-2xl">
              {translations.title[language]}
            </h1>
            <div className="w-32 h-1 bg-gradient-to-r from-orange-500 to-red-500 mx-auto rounded-full mb-4"></div>
            <p className="text-slate-300 text-xl font-medium">
              {translations.subtitle[language]}
            </p>
            <p className="text-slate-400 text-sm mt-2">
              {language === 'es' ? 'Por Paul Mora' : 'By Paul Mora'}
            </p>
          </div>

          {/* Menu buttons - Estilo Majotori */}
          <div className="space-y-4">
            <button
              onClick={onStartGame}
              className="w-full bg-gradient-to-r from-orange-600 via-red-600 to-orange-600 hover:from-orange-700 hover:via-red-700 hover:to-orange-700 text-white font-bold py-5 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-2xl border border-orange-400/30 group"
            >
              <Play className="w-6 h-6 group-hover:animate-pulse" />
              <span className="text-xl">{translations.startGame[language]}</span>
              <Zap className="w-5 h-5 group-hover:animate-bounce" />
            </button>

            {hasSavedGame && (
              <button
                onClick={onContinueGame}
                className="w-full bg-gradient-to-r from-blue-600 via-cyan-600 to-blue-600 hover:from-blue-700 hover:via-cyan-700 hover:to-blue-700 text-white font-bold py-5 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-2xl border border-blue-400/30 group"
              >
                <BookOpen className="w-6 h-6 group-hover:animate-pulse" />
                <span className="text-xl">{translations.continueGame[language]}</span>
              </button>
            )}

            <button
              onClick={onShowCredits}
              className="w-full bg-gradient-to-r from-purple-600 via-pink-600 to-purple-600 hover:from-purple-700 hover:via-pink-700 hover:to-purple-700 text-white font-bold py-5 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-2xl border border-purple-400/30 group"
            >
              <Award className="w-6 h-6 group-hover:animate-pulse" />
              <span className="text-xl">{translations.credits[language]}</span>
            </button>

            <button
              onClick={onToggleLanguage}
              className="w-full bg-gradient-to-r from-slate-700 to-slate-600 hover:from-slate-600 hover:to-slate-500 text-white font-bold py-4 px-8 rounded-xl transition-all duration-300 flex items-center justify-center space-x-3 shadow-xl border border-slate-500/30"
            >
              <Settings className="w-5 h-5" />
              <span>{translations.language[language]}: {language === 'es' ? 'Español' : 'English'}</span>
            </button>
          </div>

          {/* Footer */}
          <div className="mt-12 text-center text-slate-400 text-sm">
            <p>© 2025 Paul Mora - {language === 'es' ? 'Todos los derechos reservados' : 'All rights reserved'}</p>
            <p className="mt-2 text-xs opacity-75">
              {language === 'es' 
                ? 'Una experiencia inmersiva sobre la industria petrolera' 
                : 'An immersive experience about the petroleum industry'
              }
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainMenu;