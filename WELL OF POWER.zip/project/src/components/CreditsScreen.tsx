import React from 'react';
import { translations } from '../data/translations';
import { ArrowLeft, Heart, Code, Palette, Zap, Award } from 'lucide-react';

interface CreditsScreenProps {
  language: 'es' | 'en';
  onBack: () => void;
}

const CreditsScreen: React.FC<CreditsScreenProps> = ({ language, onBack }) => {
  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background - Estilo Majotori */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-purple-900 to-slate-800" />
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-20 transform scale-105"
        style={{ backgroundImage: `url('https://images.pexels.com/photos/256648/pexels-photo-256648.jpeg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80" />
      
      {/* Animated particles */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-orange-400 rounded-full animate-pulse opacity-60"></div>
        <div className="absolute top-1/2 right-1/4 w-3 h-3 bg-blue-400 rounded-full animate-ping opacity-40"></div>
        <div className="absolute bottom-1/3 left-1/3 w-1 h-1 bg-yellow-400 rounded-full animate-pulse opacity-50"></div>
        <div className="absolute top-3/4 right-1/2 w-2 h-2 bg-red-400 rounded-full animate-ping opacity-60"></div>
      </div>
      
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="max-w-3xl w-full">
          <button
            onClick={onBack}
            className="mb-8 flex items-center space-x-3 text-slate-300 hover:text-white transition-colors bg-slate-800/50 hover:bg-slate-700/50 px-4 py-2 rounded-lg backdrop-blur-sm"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">{language === 'es' ? 'Volver' : 'Back'}</span>
          </button>

          <div className="bg-black/90 backdrop-blur-md rounded-2xl p-10 shadow-2xl border border-white/20">
            {/* Header */}
            <div className="text-center mb-10">
              <div className="relative mb-6">
                <div className="w-24 h-24 mx-auto bg-gradient-to-br from-orange-500 via-red-600 to-orange-500 rounded-full flex items-center justify-center shadow-2xl border-4 border-white/20">
                  <Heart className="w-12 h-12 text-white" />
                </div>
                <div className="absolute inset-0 w-24 h-24 mx-auto bg-gradient-to-br from-orange-500/30 to-red-600/30 rounded-full blur-xl"></div>
              </div>
              
              <h1 className="text-4xl font-bold text-white mb-3 tracking-wider">
                WELL OF POWER
              </h1>
              <div className="w-32 h-1 bg-gradient-to-r from-orange-500 to-red-500 mx-auto rounded-full mb-4"></div>
              <p className="text-slate-300 text-xl">
                {language === 'es' ? 'Novela Visual Petrolera' : 'Petroleum Visual Novel'}
              </p>
            </div>

            <div className="space-y-8">
              {/* Creator */}
              <div className="text-center bg-slate-800/50 rounded-xl p-6 border border-slate-700/50">
                <div className="flex items-center justify-center space-x-3 mb-4">
                  <Code className="w-6 h-6 text-orange-400" />
                  <h3 className="text-2xl font-bold text-white">
                    {language === 'es' ? 'Creador y Desarrollador' : 'Creator and Developer'}
                  </h3>
                  <Zap className="w-6 h-6 text-orange-400" />
                </div>
                <p className="text-3xl font-bold text-transparent bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text">
                  PAUL MORA
                </p>
              </div>

              {/* Special Thanks */}
              <div className="border-t border-slate-700 pt-8">
                <div className="flex items-center justify-center space-x-3 mb-6">
                  <Palette className="w-6 h-6 text-blue-400" />
                  <h3 className="text-xl font-bold text-white">
                    {language === 'es' ? 'Agradecimientos Especiales' : 'Special Thanks'}
                  </h3>
                </div>
                <div className="text-slate-300 text-center space-y-3 bg-slate-800/30 rounded-xl p-6">
                  <p className="text-lg">
                    {language === 'es' 
                      ? 'A todos los profesionales de la industria petrolera' 
                      : 'To all petroleum industry professionals'
                    }
                  </p>
                  <p className="text-lg">
                    {language === 'es' 
                      ? 'que inspiraron esta experiencia educativa' 
                      : 'who inspired this educational experience'
                    }
                  </p>
                </div>
              </div>

              {/* Game Features */}
              <div className="border-t border-slate-700 pt-8">
                <div className="flex items-center justify-center space-x-3 mb-6">
                  <Award className="w-6 h-6 text-purple-400" />
                  <h3 className="text-xl font-bold text-white">
                    {language === 'es' ? 'Características del Juego' : 'Game Features'}
                  </h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-slate-300">
                  <div className="bg-slate-800/30 rounded-lg p-4">
                    <p className="font-semibold text-white mb-2">
                      {language === 'es' ? '5 Etapas Profesionales' : '5 Professional Stages'}
                    </p>
                    <p className="text-sm">
                      {language === 'es' 
                        ? 'Desde pasante hasta magnate petrolero' 
                        : 'From intern to petroleum magnate'
                      }
                    </p>
                  </div>
                  <div className="bg-slate-800/30 rounded-lg p-4">
                    <p className="font-semibold text-white mb-2">
                      {language === 'es' ? 'Desafíos Técnicos' : 'Technical Challenges'}
                    </p>
                    <p className="text-sm">
                      {language === 'es' 
                        ? 'Preguntas reales de la industria' 
                        : 'Real industry questions'
                      }
                    </p>
                  </div>
                  <div className="bg-slate-800/30 rounded-lg p-4">
                    <p className="font-semibold text-white mb-2">
                      {language === 'es' ? 'Múltiples Finales' : 'Multiple Endings'}
                    </p>
                    <p className="text-sm">
                      {language === 'es' 
                        ? 'Basados en tus decisiones' 
                        : 'Based on your decisions'
                      }
                    </p>
                  </div>
                  <div className="bg-slate-800/30 rounded-lg p-4">
                    <p className="font-semibold text-white mb-2">
                      {language === 'es' ? 'Bilingüe' : 'Bilingual'}
                    </p>
                    <p className="text-sm">
                      {language === 'es' 
                        ? 'Español e Inglés' 
                        : 'Spanish and English'
                      }
                    </p>
                  </div>
                </div>
              </div>

              {/* Copyright */}
              <div className="border-t border-slate-700 pt-8">
                <div className="text-center text-slate-400 space-y-3">
                  <p className="font-bold text-lg">© 2025 Paul Mora</p>
                  <p>{language === 'es' ? 'Todos los derechos reservados' : 'All rights reserved'}</p>
                  <p className="text-sm opacity-75">
                    {language === 'es' 
                      ? 'Una experiencia inmersiva sobre la industria petrolera' 
                      : 'An immersive experience about the petroleum industry'
                    }
                  </p>
                </div>
              </div>

              {/* Footer message */}
              <div className="text-center pt-6">
                <p className="text-slate-500 text-sm italic">
                  {language === 'es' 
                    ? 'Hecho con pasión para educar y entretener' 
                    : 'Made with passion to educate and entertain'
                  }
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreditsScreen;