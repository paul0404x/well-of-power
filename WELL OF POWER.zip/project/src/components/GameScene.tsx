import React from 'react';
import { Dilema, Option } from '../types/game';
import { translations } from '../data/translations';
import { ChevronRight, Zap, AlertTriangle } from 'lucide-react';

interface GameSceneProps {
  dilema: Dilema;
  language: 'es' | 'en';
  showResponse: boolean;
  selectedOption: Option | null;
  onSelectOption: (option: Option) => void;
  onContinue: () => void;
  phase: string;
}

const GameScene: React.FC<GameSceneProps> = ({
  dilema,
  language,
  showResponse,
  selectedOption,
  onSelectOption,
  onContinue,
  phase
}) => {
  const getText = (text: any) => {
    if (typeof text === 'string') return text;
    return text[language] || text.es;
  };

  const phaseTitle = translations.phases[phase as keyof typeof translations.phases]?.[language] || '';

  const backgroundImages = {
    intern: 'https://images.pexels.com/photos/159888/pexels-photo-159888.jpeg',
    junior: 'https://images.pexels.com/photos/73833/oil-pump-jack-sunset-clouds-73833.jpeg',
    supervisor: 'https://images.pexels.com/photos/162568/oil-rig-sea-ocean-horizon-162568.jpeg',
    manager: 'https://images.pexels.com/photos/373543/pexels-photo-373543.jpeg',
    magnate: 'https://images.pexels.com/photos/534216/pexels-photo-534216.jpeg'
  };

  const characterImages = {
    'paul.png': 'https://images.pexels.com/photos/2182970/pexels-photo-2182970.jpeg',
    'carlos.png': 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg',
    'javier.png': 'https://images.pexels.com/photos/1040881/pexels-photo-1040881.jpeg',
    'laura.png': 'https://images.pexels.com/photos/3756679/pexels-photo-3756679.jpeg',
    'sr_torres.png': 'https://images.pexels.com/photos/1043474/pexels-photo-1043474.jpeg'
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background - Estilo Majotori con overlay más sutil */}
      <div 
        className="absolute inset-0 bg-cover bg-center transform scale-105"
        style={{ backgroundImage: `url(${backgroundImages[phase as keyof typeof backgroundImages]})` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/60 to-black/80" />
      
      {/* Particles effect overlay */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-2 h-2 bg-orange-400 rounded-full animate-pulse"></div>
        <div className="absolute top-3/4 right-1/3 w-1 h-1 bg-blue-400 rounded-full animate-ping"></div>
        <div className="absolute bottom-1/4 left-1/2 w-1.5 h-1.5 bg-yellow-400 rounded-full animate-pulse"></div>
      </div>

      {/* Phase indicator - Estilo Majotori */}
      <div className="absolute top-6 left-6 z-20">
        <div className="bg-gradient-to-r from-orange-600 via-red-600 to-orange-600 text-white px-6 py-3 rounded-full font-bold text-sm tracking-wider shadow-2xl border-2 border-orange-300/50">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
            <span>{phaseTitle}</span>
          </div>
        </div>
      </div>

      {/* Challenge indicator - Más prominente estilo Majotori */}
      {dilema.tipo === 'desafio' && (
        <div className="absolute top-6 right-6 z-20">
          <div className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 text-white px-6 py-3 rounded-full font-bold text-sm flex items-center space-x-2 animate-pulse shadow-2xl border-2 border-yellow-300/50">
            <AlertTriangle className="w-5 h-5" />
            <span>{language === 'es' ? 'DESAFÍO TÉCNICO' : 'TECHNICAL CHALLENGE'}</span>
            <Zap className="w-4 h-4" />
          </div>
        </div>
      )}

      {/* Main content - Layout estilo Majotori */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Character portrait - Más grande y prominente */}
        {dilema.personaje_imagen && (
          <div className="flex justify-center pt-16 pb-8">
            <div className="relative">
              <div className="w-40 h-40 rounded-full border-4 border-white shadow-2xl overflow-hidden bg-gradient-to-br from-blue-400 to-purple-600 p-1">
                <img 
                  src={characterImages[dilema.personaje_imagen as keyof typeof characterImages] || 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg'}
                  alt="Character"
                  className="w-full h-full object-cover rounded-full"
                />
              </div>
              {/* Glow effect */}
              <div className="absolute inset-0 rounded-full bg-gradient-to-r from-blue-400/20 to-purple-600/20 blur-xl"></div>
            </div>
          </div>
        )}

        {/* Dialog section - Estilo Majotori con mejor spacing */}
        <div className="flex-1 flex items-center justify-center px-4 pb-8">
          <div className="max-w-4xl w-full">
            {/* Title */}
            <div className="text-center mb-8">
              <h2 className="text-4xl font-bold text-white mb-2 drop-shadow-2xl">
                {dilema.titulo}
              </h2>
              <div className="w-24 h-1 bg-gradient-to-r from-orange-500 to-red-500 mx-auto rounded-full"></div>
            </div>
            
            {/* Situation box - Estilo Majotori */}
            <div className="bg-black/80 backdrop-blur-md rounded-2xl p-8 mb-8 shadow-2xl border border-white/20">
              <div className="relative">
                <div className="absolute -top-4 -left-4 w-8 h-8 bg-gradient-to-br from-orange-500 to-red-500 rounded-full"></div>
                <p className="text-white leading-relaxed text-lg font-medium">
                  {getText(dilema.situacion)}
                </p>
              </div>
            </div>

            {!showResponse ? (
              /* Options - Estilo Majotori con 3 opciones */
              <div className="space-y-4">
                {dilema.opciones.map((opcion, index) => (
                  <button
                    key={index}
                    onClick={() => onSelectOption(opcion)}
                    className="w-full text-left bg-gradient-to-r from-slate-800/90 to-slate-700/90 hover:from-slate-700/90 hover:to-slate-600/90 text-white p-6 rounded-xl transition-all duration-300 transform hover:scale-[1.02] hover:shadow-2xl border border-slate-600/50 hover:border-slate-400/50 backdrop-blur-sm group"
                  >
                    <div className="flex items-center">
                      <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-br from-blue-600 to-cyan-600 rounded-full flex items-center justify-center text-lg font-bold mr-4 group-hover:from-blue-500 group-hover:to-cyan-500 transition-all duration-300 shadow-lg">
                        {String.fromCharCode(65 + index)}
                      </div>
                      <span className="text-white text-lg font-medium leading-relaxed">
                        {getText(opcion.texto)}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            ) : (
              /* Response section - Estilo Majotori */
              <div className="space-y-6">
                <div className={`p-6 rounded-xl border-l-4 backdrop-blur-md ${
                  selectedOption?.es_correcta 
                    ? 'bg-green-900/60 border-green-400 text-green-100' 
                    : dilema.tipo === 'desafio' && !selectedOption?.es_correcta
                    ? 'bg-red-900/60 border-red-400 text-red-100'
                    : 'bg-blue-900/60 border-blue-400 text-blue-100'
                } shadow-2xl`}>
                  <div className="flex items-start space-x-4">
                    {selectedOption?.es_correcta ? (
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <span className="text-white font-bold">✓</span>
                      </div>
                    ) : dilema.tipo === 'desafio' && !selectedOption?.es_correcta ? (
                      <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <span className="text-white font-bold">✗</span>
                      </div>
                    ) : (
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                        <span className="text-white font-bold">i</span>
                      </div>
                    )}
                    <p className="leading-relaxed text-lg font-medium">
                      {getText(selectedOption?.respuesta_narrativa)}
                    </p>
                  </div>
                </div>
                
                <button
                  onClick={onContinue}
                  className="w-full bg-gradient-to-r from-blue-600 via-cyan-600 to-blue-600 hover:from-blue-700 hover:via-cyan-700 hover:to-blue-700 text-white font-bold py-6 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-2xl border border-blue-400/30"
                >
                  <span className="text-xl">{translations.continue[language]}</span>
                  <ChevronRight className="w-6 h-6" />
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameScene;