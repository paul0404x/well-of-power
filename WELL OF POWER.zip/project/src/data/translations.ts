export const translations = {
  title: {
    es: "WELL OF POWER",
    en: "WELL OF POWER"
  },
  subtitle: {
    es: "Una Novela Visual Petrolera",
    en: "A Petroleum Visual Novel"
  },
  startGame: {
    es: "COMENZAR JUEGO",
    en: "START GAME"
  },
  continueGame: {
    es: "CONTINUAR",
    en: "CONTINUE"
  },
  credits: {
    es: "CRÉDITOS",
    en: "CREDITS"
  },
  settings: {
    es: "CONFIGURACIÓN",
    en: "SETTINGS"
  },
  language: {
    es: "Idioma",
    en: "Language"
  },
  stats: {
    reputacion: {
      es: "Reputación",
      en: "Reputation"
    },
    conocimiento: {
      es: "Conocimiento",
      en: "Knowledge"
    },
    capital: {
      es: "Capital",
      en: "Capital"
    },
    red_contactos: {
      es: "Red de Contactos",
      en: "Network"
    }
  },
  continue: {
    es: "Continuar",
    en: "Continue"
  },
  gameCredits: {
    es: "Creado por Paul Mora\n\nWELL OF POWER - Novela Visual\n\nUna experiencia inmersiva sobre la industria petrolera\n\nTodos los derechos reservados © 2025",
    en: "Created by Paul Mora\n\nWELL OF POWER - Visual Novel\n\nAn immersive experience about the petroleum industry\n\nAll rights reserved © 2025"
  },
  phases: {
    intern: { es: "EL PASANTE", en: "THE INTERN" },
    junior: { es: "INGENIERO JUNIOR", en: "JUNIOR ENGINEER" },
    supervisor: { es: "SUPERVISOR DE CAMPO", en: "FIELD SUPERVISOR" },
    manager: { es: "GERENTE DE PROYECTO", en: "PROJECT MANAGER" },
    magnate: { es: "EL SALTO DEL MAGNATE", en: "THE MAGNATE'S LEAP" }
  }
};