import { useState, useEffect } from 'react';
import { GameState, GameStats } from '../types/game';

const STORAGE_KEY = 'well-of-power-save';

const initialStats: GameStats = {
  reputacion: 5,
  conocimiento: 5,
  capital: 1000,
  red_contactos: 5
};

const initialState: GameState = {
  currentDilema: 0,
  stats: initialStats,
  gamePhase: 'menu',
  showResponse: false,
  selectedOption: null,
  language: 'es'
};

export const useGameState = () => {
  const [gameState, setGameState] = useState<GameState>(initialState);

  // Load saved game on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsedState = JSON.parse(saved);
        setGameState(parsedState);
      } catch (error) {
        console.error('Error loading saved game:', error);
      }
    }
  }, []);

  // Save game whenever state changes
  useEffect(() => {
    if (gameState.gamePhase !== 'menu') {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(gameState));
    }
  }, [gameState]);

  const updateStats = (consequences: Partial<GameStats>) => {
    setGameState(prev => ({
      ...prev,
      stats: {
        reputacion: Math.max(0, Math.min(20, prev.stats.reputacion + (consequences.reputacion || 0))),
        conocimiento: Math.max(0, Math.min(20, prev.stats.conocimiento + (consequences.conocimiento || 0))),
        capital: Math.max(0, prev.stats.capital + (consequences.capital || 0)),
        red_contactos: Math.max(0, Math.min(20, prev.stats.red_contactos + (consequences.red_contactos || 0)))
      }
    }));
  };

  const startNewGame = () => {
    setGameState({
      ...initialState,
      gamePhase: 'playing',
      language: gameState.language
    });
    localStorage.removeItem(STORAGE_KEY);
  };

  const continueGame = () => {
    setGameState(prev => ({ ...prev, gamePhase: 'playing' }));
  };

  const nextDilema = () => {
    setGameState(prev => ({
      ...prev,
      currentDilema: prev.currentDilema + 1,
      showResponse: false,
      selectedOption: null
    }));
  };

  const selectOption = (option: any) => {
    setGameState(prev => ({
      ...prev,
      selectedOption: option,
      showResponse: true
    }));
    updateStats(option.consecuencias);
  };

  const setLanguage = (language: 'es' | 'en') => {
    setGameState(prev => ({ ...prev, language }));
  };

  const getPhase = () => {
    const { currentDilema } = gameState;
    if (currentDilema <= 12) return 'intern';
    if (currentDilema <= 18) return 'junior';
    if (currentDilema <= 23) return 'supervisor';
    if (currentDilema <= 28) return 'manager';
    return 'magnate';
  };

  return {
    gameState,
    updateStats,
    startNewGame,
    continueGame,
    nextDilema,
    selectOption,
    setLanguage,
    getPhase
  };
};