import React from 'react';
import { GameStats } from '../types/game';
import { translations } from '../data/translations';
import { Trophy, RefreshCw, Home, Crown, Star, Award } from 'lucide-react';

interface EndScreenProps {
  stats: GameStats;
  language: 'es' | 'en';
  onRestart: () => void;
  onMainMenu: () => void;
}

const EndScreen: React.FC<EndScreenProps> = ({ stats, language, onRestart, onMainMenu }) => {
  const getEnding = () => {
    const { reputacion, conocimiento, capital, red_contactos } = stats;
    const total = reputacion + conocimiento + (capital / 100000) + red_contactos;

    if (total >= 60) {
      return {
        title: language === 'es' ? 'EL BARÓN DEL PETRÓLEO' : 'THE OIL BARON',
        description: language === 'es' 
          ? 'Has conquistado la industria petrolera. Tu nombre será recordado por generaciones como uno de los grandes magnates de la energía.'
          : 'You have conquered the petroleum industry. Your name will be remembered for generations as one of the great energy magnates.',
        color: 'from-yellow-400 via-orange-500 to-red-500',
        icon: Crown
      };
    } else if (total >= 45) {
      return {
        title: language === 'es' ? 'EL CEO VISIONARIO' : 'THE VISIONARY CEO',
        description: language === 'es'
          ? 'Has transformado MegaPetrol en una empresa del futuro, equilibrando rentabilidad con responsabilidad.'
          : 'You have transformed MegaPetrol into a company of the future, balancing profitability with responsibility.',
        color: 'from-blue-400 via-purple-500 to-pink-500',
        icon: Star
      };
    } else if (total >= 30) {
      return {
        title: language === 'es' ? 'EL PROFESIONAL EXITOSO' : 'THE SUCCESSFUL PROFESSIONAL',
        description: language === 'es'
          ? 'Has construido una sólida carrera en la industria petrolera, ganándote el respeto de tus pares.'
          : 'You have built a solid career in the petroleum industry, earning the respect of your peers.',
        color: 'from-green-400 via-blue-500 to-cyan-500',
        icon: Award
      };
    } else {
      return {
        title: language === 'es' ? 'EL APRENDIZ ETERNO' : 'THE ETERNAL APPRENTICE',
        description: language === 'es'
          ? 'Tu viaje apenas comienza. Cada experiencia te ha enseñado lecciones valiosas para el futuro.'
          : 'Your journey is just beginning. Each experience has taught you valuable lessons for the future.',
        color: 'from-slate-400 via-slate-500 to-slate-600',
        icon: Trophy
      };
    }
  };

  const ending = getEnding();
  const EndingIcon = ending.icon;

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background - Estilo Majotori */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-slate-800" />
      <div 
        className="absolute inset-0 bg-cover bg-center opacity-30 transform scale-105"
        style={{ backgroundImage: `url('https://images.pexels.com/photos/256648/pexels-photo-256648.jpeg')` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80" />
      
      {/* Celebratory particles */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-3 h-3 bg-yellow-400 rounded-full animate-bounce opacity-80"></div>
        <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-orange-400 rounded-full animate-ping opacity-60"></div>
        <div className="absolute bottom-1/3 left-1/3 w-4 h-4 bg-red-400 rounded-full animate-pulse opacity-70"></div>
        <div className="absolute top-3/4 right-1/2 w-2 h-2 bg-blue-400 rounded-full animate-bounce opacity-60"></div>
        <div className="absolute top-1/6 right-1/6 w-1 h-1 bg-purple-400 rounded-full animate-ping opacity-80"></div>
      </div>
      
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="max-w-3xl w-full">
          <div className="bg-black/90 backdrop-blur-md rounded-2xl p-10 shadow-2xl border border-white/20">
            {/* Achievement Header */}
            <div className="text-center mb-10">
              <div className="relative mb-8">
                <div className={`w-32 h-32 mx-auto bg-gradient-to-br ${ending.color} rounded-full flex items-center justify-center shadow-2xl border-4 border-white/30`}>
                  <EndingIcon className="w-16 h-16 text-white drop-shadow-lg" />
                </div>
                <div className={`absolute inset-0 w-32 h-32 mx-auto bg-gradient-to-br ${ending.color} opacity-30 rounded-full blur-2xl`}></div>
              </div>
              
              <h1 className={`text-4xl font-bold mb-4 tracking-wider bg-gradient-to-r ${ending.color} bg-clip-text text-transparent`}>
                {ending.title}
              </h1>
              <div className={`w-40 h-1 bg-gradient-to-r ${ending.color} mx-auto rounded-full mb-6`}></div>
              <p className="text-slate-300 text-lg leading-relaxed max-w-2xl mx-auto">
                {ending.description}
              </p>
            </div>

            {/* Final Statistics */}
            <div className="bg-slate-800/60 rounded-xl p-8 mb-10 border border-slate-700/50">
              <h3 className="text-2xl font-bold text-white mb-6 text-center">
                {language === 'es' ? 'Estadísticas Finales' : 'Final Statistics'}
              </h3>
              <div className="grid grid-cols-2 gap-6">
                {Object.entries(stats).map(([key, value]) => {
                  const label = translations.stats[key as keyof typeof translations.stats][language];
                  const displayValue = key === 'capital' ? `$${(value / 1000000).toFixed(1)}M` : value;
                  
                  const colorSchemes = {
                    reputacion: 'from-green-500 to-emerald-400',
                    conocimiento: 'from-blue-500 to-cyan-400',
                    capital: 'from-yellow-500 to-orange-400',
                    red_contactos: 'from-purple-500 to-pink-400'
                  };
                  
                  return (
                    <div key={key} className="text-center bg-slate-700/30 rounded-lg p-4">
                      <p className="text-slate-300 text-sm font-medium mb-2">{label}</p>
                      <p className={`text-2xl font-bold bg-gradient-to-r ${colorSchemes[key as keyof typeof colorSchemes]} bg-clip-text text-transparent`}>
                        {displayValue}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-4">
              <button
                onClick={onRestart}
                className="w-full bg-gradient-to-r from-orange-600 via-red-600 to-orange-600 hover:from-orange-700 hover:via-red-700 hover:to-orange-700 text-white font-bold py-5 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-3 shadow-2xl border border-orange-400/30"
              >
                <RefreshCw className="w-6 h-6" />
                <span className="text-xl">{language === 'es' ? 'Jugar de Nuevo' : 'Play Again'}</span>
              </button>

              <button
                onClick={onMainMenu}
                className="w-full bg-gradient-to-r from-slate-700 to-slate-600 hover:from-slate-600 hover:to-slate-500 text-white font-bold py-5 px-8 rounded-xl transition-all duration-300 flex items-center justify-center space-x-3 shadow-xl border border-slate-500/30"
              >
                <Home className="w-6 h-6" />
                <span className="text-xl">{language === 'es' ? 'Menú Principal' : 'Main Menu'}</span>
              </button>
            </div>

            {/* Thank you message */}
            <div className="mt-10 text-center">
              <p className="text-slate-400 text-lg">
                {language === 'es' ? 'Gracias por jugar' : 'Thanks for playing'}
              </p>
              <p className="text-2xl font-bold text-transparent bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text mt-2">
                WELL OF POWER
              </p>
              <p className="text-slate-500 text-sm mt-2">
                {language === 'es' ? 'Por Paul Mora' : 'By Paul Mora'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EndScreen;